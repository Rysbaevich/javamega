package kg.itschool.crm.dao;

import kg.itschool.crm.model.Group;

public interface GroupDao extends CrudDao<Group> {

}
