package kg.itschool.crm.dao;

import kg.itschool.crm.model.Mentor;


public interface MentorDao extends CrudDao<Mentor> {

}
