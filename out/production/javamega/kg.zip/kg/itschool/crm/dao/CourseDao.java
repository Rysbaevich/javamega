package kg.itschool.crm.dao;

import kg.itschool.crm.model.Course;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public interface CourseDao extends CrudDao<Course> {

}