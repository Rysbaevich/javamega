package kg.itschool.crm.dao;

import kg.itschool.crm.model.Address;

public interface AddressDao extends CrudDao<Address> {

}
