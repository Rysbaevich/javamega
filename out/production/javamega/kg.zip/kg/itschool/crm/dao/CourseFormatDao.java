package kg.itschool.crm.dao;

import kg.itschool.crm.model.CourseFormat;

public interface CourseFormatDao extends CrudDao<CourseFormat> {

}
