package kg.itschool.crm.dao;

import kg.itschool.crm.model.Manager;

public interface ManagerDao extends CrudDao<Manager> {

}
