package kg.itschool.crm.dao;

import kg.itschool.crm.model.Student;

public interface StudentDao extends CrudDao<Student> {

}
